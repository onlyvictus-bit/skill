# Operating the optional knowledge layer

The explicit projection/vector commands below are the project-1 compatibility route. For current automatic extraction, selective refresh, observed tests and admission use [project-2](knowledge-project-2.md). Bridge1.2 optional models and advanced routes are documented in [local models](knowledge-models.md) and [advanced retrieval](knowledge-advanced.md).

All commands use `scripts/memory_integrity_workflow.py` and an explicit `--claude-mon-root`. Existing commands and historical releases remain valid. No automatic background index or worker installation occurs.

Knowledge workers now default to **120 seconds per invocation**, including fresh
evidence replay. A measured cold community worker needed41.906seconds, mainly
loading dependencies;30seconds was insufficient in that observation. This is a
bounded deadline, not a mandatory wait: completed workers return immediately.
`--worker-timeout` controls knowledge commands; `--knowledge-worker-timeout`
controls knowledge replay in `offline-run`/`verify`. Explicit smaller budgets
remain supported; the existing maximum120seconds, shared distributed deadline,
termination and evidence-refusal checks are unchanged. Native experimental
qualification is not enabled by this setting.

1. Create an isolated Python 3.12 environment outside the skill. From this repository install `python -m pip install -r semantica-runtime/requirements-lock.txt`. If needed create it with `python3.12 -m venv /absolute/runtime`; use that environment's absolute Python path below. The lock pins Semantica to an immutable Git revision and pyshacl. It is deliberately substantial; Semantica core imports require its core dependencies.
2. Write a source map, explicit reviewed projection, current policy and independent task contract using [bridge contracts](knowledge-contract.md).
3. Check the selected environment: `python scripts/memory_integrity_workflow.py knowledge-status --claude-mon-root /absolute/claude-mon --worker-python /absolute/runtime/bin/python` (Windows: `Scripts/python.exe`). Without a worker, readiness is DEGRADED/BLOCKED for graph-required tasks.
4. Build: `python scripts/memory_integrity_workflow.py knowledge-index --claude-mon-root /absolute/claude-mon --project-root /absolute/project --index-dir /absolute/project-index --source-map sources.json --projection-file projection.json`.
5. Retrieve: `python scripts/memory_integrity_workflow.py knowledge-retrieve --claude-mon-root /absolute/claude-mon --project-root /absolute/project --index-dir /absolute/project-index --policy-file access.json --task-file obligations.json --query-vector '[1,0]' --query-model reviewed-vectors-v1 --worker-python /absolute/runtime/bin/python --max-hops 2 --seeds 1 --max-visits 100 --max-results 50 --evidence-pack /absolute/new-pack.json`.
6. For the existing offline workflow, pass `--knowledge-pack /absolute/new-pack.json --knowledge-index /absolute/project-index --knowledge-root /absolute/project --knowledge-policy access.json --knowledge-task obligations.json --knowledge-worker-python /absolute/runtime/bin/python` to `offline-run` alongside the ordinary source/task/responses/run-dir options. Bind the execution digest first. The pack goes through existing context measurement before approval and dispatch. This is an offline fake-provider fixture, not live model qualification.
7. Verify with the same knowledge index/root/policy/task/worker options and optionally `--require-knowledge`. An explicit knowledge basis already requires verification. Use `knowledge-audit` with project/index/policy/task/worker, `--source`, verified `--run-map` and separate `--expected-claims oracle.json` to inspect structured gaps. Unknown semantic stages remain blocked/unverified.

Never delete uncertain execution history or blindly resend. CURRENT exposes a single immutable generation. A writer lock blocks parallel publication; after a crashed writer, inspect process state and retained generation/pointer files before explicitly removing a confirmed stale lock. A failed prepublication build leaves the previous CURRENT usable. Do not remove or overwrite historical generations to repair freshness. Project-1 requires rebuilding after source/branch/commit changes. Project-2 allows same-branch unrelated commits, selectively invalidates stale facts and refreshes affected extraction fragments; all referenced source hashes and current ACLs are checked again. Any changed current pack, task or policy requires a fresh isolated run rather than resuming a different basis.

This v1 supports atomic pointer replacement, not full power-loss durability on all filesystems; it fsyncs files but does not claim distributed transactions or OS directory-fsync guarantees. Project-1 rebuilds whole generations. Project-2 reuses sealed unchanged extraction fragments and recomputes dependency resolution when publishing the next immutable generation. Raw index files are not an ACL boundary.

Portable release: keep `memory-integrity-knowledge-v2.zip` with `claude-mon-knowledge-v2.zip` for bridge1.2; the v1 pair remains historical. Run `python -B release/Verify-Knowledge-Bridge.py`; select the real runtime through `KNOWLEDGE_WORKER_PYTHON` to also exercise actual Semantica tests. Default host checks explicitly skip the optional runtime tests. The paired bridge ZIPs contain the skill/companion; the separately pinned runtime installer remains in the repository. Run the fixture comparison from memory-integrity/scripts: `python -B -m knowledge_bridge.benchmark --claude-mon-root /absolute/claude-mon --worker-python /absolute/runtime/bin/python`.

Rollback: use the retained R4 pair and its verifier or revert the bridge commit in Git. Preserve run histories; graph-required v1 runs still require their bridge for verification. Portable ZIP verification does not install a skill. Managed installation is a separate explicit promotion with a receipt; generic native qualification remains unsupported. Full coding/model quality and representative workload benefit remain UNVERIFIED; default graph behavior stays off.

Integrity repair: if preflight rejects a nested receipt, preserve the old run and rebuild a current pack through knowledge-retrieve. Do not edit or rehash a receipt to invent a backend, lineage or SHACL result. knowledge-audit now reports conflicting actual retrieval/prompt assertions even when IDs match. It independently reopens the oracle's permitted source references, so an unretrieved source unit is a retrieval/context gap rather than a fabricated source failure. Partial observations remain limitations.

Automatic coding workflow: use [project-2](knowledge-project-2.md) for knowledge-project/refresh/impact, text queries and reverse traversal, observed local tests, admission and Fable consumption. The explicit projection/vector instructions above remain the project-1 compatibility route.
